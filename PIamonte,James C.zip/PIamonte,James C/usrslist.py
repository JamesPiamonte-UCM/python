from os import system

users: list = [
    {'username': 'alpha','password':'hello123'},
    {'username': 'bravo','password':'hello123'},
    {'username': 'charlie','password':'hello123'},
]

username: str = None
password: str = None

#Corrected decorator to properly accept arguments
def userinput(formname: str):
    def decorator(func):
        def wrapper(*args, **kwargs):
            global username, password
            system("cls")
            print(formname.upper().center(21,"-"))
            username = input("Enter username: ")
            password = input("Enter password: ")
            return func(*args, **kwargs)
        return wrapper
    return decorator
    
@userinput("add user")
def add() -> None:
    user = {'username': username,'password': password}
    users.append(user)
    print("New User Added")   

@userinput("Find User")
def find() -> None:
    user = {'username': username,'password': password}
    if user in users:
        print(f"User Found: {user}")
    else:
        print("User Not Found!")

@userinput("Delete User")
def delete() -> None:
    user = {'username': username,'password': password}
    if user in users:
        print(user)
        opt: str = input("Do you really want to delete this y/n: ")
        if opt.upper() == "Y":
            users.remove(user)
            print("User HAS BEEN DELETED!!! ")
        else:
            print("User NOT DELETED!!! ")
    else:
        print("User Not Found! ")

@userinput("Update User")
def update() -> None:
    user = {'username': username,'password': password}
    if user in users:
        index: int = users.index(user)
        print("User Found: ", end="")
        print(user)
        opt: str = input("Do you really want to UPDATE this (y/n): ")
        if opt.upper() == "Y":
            uname: str = input("New Username: ")
            pword: str = input("New Password: ")
            newuser = {'username': uname,'password': pword}
            users[index] = newuser
            print("User HAS BEEN UPDATED!!! ")
        else:
            print("User NOT UPDATED!!! ")
    else:
        print("User Not Found!")

def display() -> None:
    system("cls")
    print(" -- USER LIST ", end="")
    print("="*60)
    if len(users) > 0:
        for user in users:
            #Fixed the mismatched parentheses and brackets syntax error here
            print(f"{user['username']}\t{user['password']}")
    print("-"*73)

#Renamed this from 'main' to 'menu' so it can be called inside the main()
def menu() -> None:
    system("cls")
    print("MAIN MENU".center(21,"-"))
    print("1. ADD USER")
    print("2. FIND USER")
    print("3. DELETE USER")
    print("4. UPDATE USER")
    print("5. DISPLAY ALL USER")
    print("0. QUIT/END")
    print("-" * 21)

def main() -> None:
    option: int = 9999
    while option != 0:
        menu()
        try:
            option = int(input("Enter option (0..5): "))
            if option == 1: add()
            elif option == 2: find()
            elif option == 3: delete()
            elif option == 4: update()
            elif option == 5: display()
            elif option == 0: print("Program End...")
            else: print("Invalid Option!")
        except ValueError as e:
            print(f"Input Error: {e}")
            
        input("\nPress Enter to Continue...")

if __name__ == "__main__":
    main()