from os import system
import multiuser

def main()->None:
    system("cls")

#global vars
a:int = 0
b:int = 0

def mathinput(label:str)->None: #create a python decorator
    def decorator(func)->None:
        def wrapper()->None:
            global a,b
            system("cls")
            print(label.upper().center(21,"-"))
            a = int(input("Enter the first value:"))
            b = int(input("Enter the second value:"))
            func()
        return wrapper
    return decorator
    
@mathinput("ADD") 
def add()->None:    print(f"The sum of {a} and {b} is {a+b}")
@mathinput("SUBTRACT")
def subtract()->None:    print(f"The difference of {a} and {b} is {a-b}")
@mathinput("MULTIPLY")
def multiply()->None:    print(f"The product of {a} and {b} is {a*b}")
@mathinput("DIVIDE")
def divide()->None:    print(f"The quotient of {a} and {b} is {a/b:.4f}")
@mathinput("EXPONENT")
def exponent()->None:    print(f"The {a} raised to the power of {b} is {a**b}")

def menu()->None:
    system("cls")
    print(" Main Menu".center(21,"-"))
    print("1. ADD")
    print("2. SUBTRACT")
    print("3. MULTIPLY")
    print("4. DIVIDE")
    print("5. EXPONENT")
    print("0. Quit/End")
    print("-"*21)

def main()->None:
    option:int = 9999
    while option !=0:
        menu()
        try:
            option = int(input("Enter option():"))
            if   option == 1: add()
            elif option == 2: subtract()
            elif option == 3: multiply()
            elif option == 4: divide()
            elif option == 5: exponent()
            elif option == 0: multiuser.main()
        except ValueError as e:
            print(f"Error:  {e}")
        input("\nPress any key to continue...")
    
    
#if __name__ =="__main__":
  #  main()