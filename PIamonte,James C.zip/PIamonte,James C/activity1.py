from os import system
def main() -> None:
    numbers = [] 
    count = 0    

    print("Enter numbers (up to 10 inputs)")

    for i in range(10):
        while True:
            try:
                n = int(input(f"Number {i + 1}: "))
                break
            except ValueError:
                print("Invalid input. Please enter an integer.")

     
        numbers.append(n)

   
        if n == 9999:
            break


    for num in numbers:
        if num != 9999:  
            count += 1

    print("Numbers entered:", numbers)
    print("Total count:", count)

if __name__ == "__main__":
    main()