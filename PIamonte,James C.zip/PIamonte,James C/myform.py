def loginform(formname:str)->None;
    def decorator(func)->None:
        def wrapper()->None:
            system("cls")
            print(formname.upper().center("-",21))
            username = input("Enter Username :")
            password = pwinput("Enter Username :")
            return func()
        return wrapper
    return decorator