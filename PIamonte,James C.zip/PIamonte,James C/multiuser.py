"""
create a multiuser login, iuser dictionary placed on list
{'username':'alpha','password':'hello123'}
{'username':'bravo','password':'hello123'}
{'username':'charlie','password':'hello123'}
{'username':'alpha','password':'hello123'}

"""
from os import system
from pwinput import pwinput
import mathmenu

users:list = [
    {'username':'alpha','password':'hello123'},
    {'username':'bravo','password':'hello123'},
    {'username':'charlie','password':'hello123'},
    {'username':'alpha','password':'hello123'}

]
username:str = None
password:str = None
global username, password

def loginform(formname:str)->None:
    def decorator(func)->None:
        def wrapper()->None:
            system("cls")
            print(formname.upper().center(21,"-"))
            username = input("Enter Username :")
            password = pwinput("Enter Password :")
            return func()
        return wrapper
    return decorator

@loginform(" user login ")
def validates()->bool:
    usr:any = {'username':username,'password':password}
    print(usr)
    ok:bool = True if usr in users else False
    return ok
    
    

def main()->None:
    ok:bool = validateuser()
    message:str = "LOGIN SUCCESS" if ok else "LOGIN FAILED"
    print(message)
    input("\nPress any key to continue")
    if ok:
        mathmenu.main()
    else:
        exit()


if __name__ =="__main__":
    main()