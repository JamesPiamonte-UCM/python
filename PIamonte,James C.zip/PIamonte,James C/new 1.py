from os import system
def main() -> None:
    system("cls")
    count = 0
    numbers = []
    
    print("Enter up to 10 numbers")
    
    for i in range(10):
        n = int (input(f"Number {i+1}:
        numbers.append(n)
        
        if n == 9999
        count += 1
        break
        
    for i in range(len(numbers) - 1):
        first = numbers[i]
        second = numbers[i+1]
        
        if first in(1,2, 9999) or second in (1,2,9999):
            count += 1
            break
    print("\nYou entered:", numbers)
    print("Total count =",count)
        
    
if __name__ == " __main__":
    main()