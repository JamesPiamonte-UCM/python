'''
	MonthlyEmployee class
'''
from Employee import Employee
class MonthlyEmployee(Employee):
    def __init__(self,idno:str,lastname:str,firstname:str,position:str,Monthly_rate:float,days_work:float)->None:
        super().__init__(idno,lastname,firstname,position)
        self.__Monthly_rate = Monthly_rate
        self.__days_work = days_work
        
    def __str__(self)->str:
        return f"{super().__str__()},{self.__Monthly_rate},{self.__days_work},{self.computeSalary()}"
        
    def computeSalary(self)->float:
        return (self.__Monthly_rate/20) * self.__days_work
        
    #setter
    def setMonthlyRate(self,Monthly_rate)->None:    self.__Monthly_rate = Monthly_rate
    def setDaysWork(self,days_work)->None:          self.__days_work = days_work
    #getter
    def getMonthlyRate(self)->float:                return self.__Monthly_rate
    def getDaysWork(self)->float:                   return self.__days_work
    
def main()->None:
    d1:Employee = MonthlyEmployee('1000','durano','dennis','principal1',70000,10.0)
    d2:Employee = MonthlyEmployee('1001','hello','world','supervisor',60000,7.5)
    print(d1)
    print(d2)
    
if __name__=="__main__":
    main()