from DailyEmployee import DailyEmployee
from MonthlyEmployee import MonthlyEmployee
from os import system

dailyemployee:list = []
monthlyemployee:list = []

idno:str= None
lastname:str= None
firstname:str= None
position:str= None


def employeeform(title:str)->None:
    def decorator(func)->None:
        def wrapper()->None:
            global idno,lastname,firstname,position
            system('cls')
            print(title.upper().center(40,"-"))
            idno = input("IDNO      :")
            lastname = input("LASTNAME  :")
            firstname = input("FIRSTNAME :")
            position = input("POSITION  :")
            print("-"*40)
            func()
        return wrapper
    return decorator
@employeeform('add employee')
def add_employee()->None:
    emptype:str = input('(D)aily (M)onthly:').upper()
    if emptype=="D":
        daily_rate=float(input("Daily Rate :"))
        daily_employee:Employee = DailyEmployee(idno,lastname,firstname,position,daily_rate,0)        
        dailyemployee.append(daily_employee)
   
    if emptype=="M":
        monthly_rate=float(input("Monthly Rate :"))
        monthly_employee:Employee = MonthlyEmployee(idno,lastname,firstname,position,monthly_rate,0)
        monthlyemployee.append(monthly_employee)
   
    print("\nNew Employee Added")
    
def find_employee()->None:
    system("cls")
    print(" FIND EMPLOYEE ".center(40,"-"))

    search_id = input("Enter IDNO: ")

    found = False

    # Search Daily Employees
    for employee in dailyemployee:
        if employee.getIdno() == search_id:
            print("\nEmployee Found!")
            print("-"*40)
            print(employee)
            found = True
            break

    # Search Monthly Employees
    if not found:
        for employee in monthlyemployee:
            if employee.getIdno() == search_id:
                print("\nEmployee Found!")
                print("-"*40)
                print(employee)
                found = True
                break

    if not found:
        print("\nEmployee not found.")

    print("-"*40)
    
def delete_employee()->None:
    system("cls")
    print(" DELETE EMPLOYEE ".center(40,"-"))

    search_id = input("Enter IDNO: ")

    # Search Daily Employees
    for i in range(len(dailyemployee)):
        if dailyemployee[i].getIdno() == search_id:
            print("\nEmployee Found:")
            print(dailyemployee[i])

            confirm = input("\nDelete this employee? (Y/N): ").upper()

            if confirm == "Y":
                dailyemployee.pop(i)
                print("\nEmployee Deleted Successfully.")
            else:
                print("\nDelete cancelled.")

            return

    # Search Monthly Employees
    for i in range(len(monthlyemployee)):
        if monthlyemployee[i].getIdno() == search_id:
            print("\nEmployee Found:")
            print(monthlyemployee[i])

            confirm = input("\nDelete this employee? (Y/N): ").upper()

            if confirm == "Y":
                monthlyemployee.pop(i)
                print("\nEmployee Deleted Successfully.")
            else:
                print("\nDelete cancelled.")

            return

    print("\nEmployee not found.")
    
def update_employee()->None:
    system("cls")
    print(" UPDATE EMPLOYEE ".center(40,"-"))

    search_id = input("Enter IDNO: ")

    # Search Daily Employees
    for employee in dailyemployee:
        if employee.getIdno() == search_id:
            print("\nEmployee Found:")
            print(employee)
            print("-"*40)
            lastname = input(f"LASTNAME [{employee.getLastname()}]: ")
            firstname = input(f"FIRSTNAME [{employee.getFirstname()}]: ")
            position = input(f"POSITION [{employee.getPosition()}]: ")
            daily_rate = input(f"DAILY RATE [{employee.getDailyRate()}]: ")

            if lastname != "":
                employee.setLastname(lastname)

            if firstname != "":
                employee.setFirstname(firstname)

            if position != "":
                employee.setPosition(position)

            if daily_rate != "":
                employee.setDailyRate(float(daily_rate))

            print("\nEmployee Updated Successfully.")
            return

    # Search Monthly Employees
    for employee in monthlyemployee:
        if employee.getIdno() == search_id:
            print("\nEmployee Found:")
            print(employee)
            print("-"*40)
            lastname = input(f"LASTNAME [{employee.getLastname()}]: ")
            firstname = input(f"FIRSTNAME [{employee.getFirstname()}]: ")
            position = input(f"POSITION [{employee.getPosition()}]: ")
            monthly_rate = input(f"MONTHLY RATE [{employee.getMonthlyRate()}]: ")

            if lastname != "":
                employee.setLastname(lastname)

            if firstname != "":
                employee.setFirstname(firstname)

            if position != "":
                employee.setPosition(position)

            if monthly_rate != "":
                employee.setMonthlyRate(float(monthly_rate))

            print("\nEmployee Updated Successfully.")
            return

    print("\nEmployee not found.")
    
def displayall_employee()->None:
    system('cls')
    if len(dailyemployee)>0:
        print("DAILY EMPLOYEE LIST")
        for employee in dailyemployee:
            print(employee)
            
    else:
        print("Daily Employee List is Empty !!!")
    print("-"*40)    
    
    if len(monthlyemployee)>0:
        print("MONTHLY EMPLOYEE LIST")
        for employee in monthlyemployee:
            print(employee)
    else:
        print("Monthly Employee List is Empty !!!")

def display_payroll()->None:
    system("cls")

    print("-----DAILY EMPLOYEE PAYROLL 9/15/2026" + "-"*40)

    if len(dailyemployee) > 0:
        for employee in dailyemployee:
            print(
                f"{employee.getIdno():<8}"
                f"{employee.getLastname():<10}"
                f"{employee.getFirstname():<12}"
                f"{employee.getPosition():<12}"
                f"{employee.getDailyRate():>8.2f}"
                f"{employee.getDaysWork():>7.0f}"
                f"{employee.computeSalary():>12.2f}"
            )
    else:
        print("                         NOTHING FOLLOWS")

    print("-"*70)
    print("                         NOTHING FOLLOWS")
    print("-"*70)

    print()

    print("-----MONTHLY EMPLOYEE PAYROLL 9/15/2026" + "-"*37)

    if len(monthlyemployee) > 0:
        for employee in monthlyemployee:
            print(
                f"{employee.getIdno():<8}"
                f"{employee.getLastname():<10}"
                f"{employee.getFirstname():<12}"
                f"{employee.getPosition():<12}"
                f"{employee.getMonthlyRate():>12,.2f}"
                f"{employee.getDaysWork():>7.0f}"
                f"{employee.computeSalary():>12,.2f}"
            )
    else:
        print("                         NOTHING FOLLOWS")

    print("-"*70)
    print("                         NOTHING FOLLOWS")
    print("-"*70)
    
def back_to_main()->None:print("Program ended..")
#
def menu()->None:
    system("cls")
    print(" MANAGE EMPLOYEE ".center(40,"-"))
    print("1. ADD EMPLOYEE")
    print("2. FIND EMPLOYEE")
    print("3. DELETE EMPLOYEE")
    print("4. UPDATE EMPLOYEE")
    print("5. DISPLAY ALL EMPLOYEE")
    print("0. BACK TO MENU")
    print("-"*40)

def main()->None:
    option:int = 99999
    while option != 0:
        menu()
        try:
            option=int(input("Enter Option(0..5):"))
            if   option == 1: add_employee()
            elif option == 2: find_employee()
            elif option == 3: delete_employee()
            elif option == 4: update_employee()
            elif option == 5: displayall_employee()
            elif option == 0: back_to_main()
            
        except Exception as e:
            print(f"Input Error : {e}")
        input("\nPress any key to continue...")   
        
if __name__=="__main__":
    main()
    
    
    
