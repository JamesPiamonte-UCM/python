'''
	Person Class
'''
class Person(object):
    #person constructor(a special method for created an object)
    def __init__(self,lastname:str,firstname:str)->None:
        self.__lastname = lastname  #private property
        self.__firstname = firstname
        
    def __str__(self)->str:
        return f"{self.__lastname},{self.__firstname}"
    
    def __eq__(self,other:object)->bool:
        if isinstance(other,Person):
            return self.__lastname==other.__lastname and self.__firstname==other.__firstname
    
    #setters (modifier)
    def setLastname(self,lastname:str)->None:       self.__lastname = lastname
    def setFirstname(self,firstname:str)->None:     self.__firstname = firstname
    #getter
    def getLastname(self)->str:                     return self.__lastname
    def getFirstname(self)->str:                    return self.__firstname
    

def main()->None:
    p:Person = Person('alpha','bravo')
    print(p)
    p.setLastname('durano')
    print(p)
    print(p.getLastname())
    
if __name__=="__main__":
    main()
    

    
    
    
    
        
    