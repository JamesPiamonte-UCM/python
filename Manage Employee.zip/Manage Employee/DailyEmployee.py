'''
	DailyEmployee class
'''
from Employee import Employee
class DailyEmployee(Employee):
    def __init__(self,idno:str,lastname:str,firstname:str,position:str,daily_rate:float,days_work:float)->None:
        super().__init__(idno,lastname,firstname,position)
        self.__daily_rate = daily_rate
        self.__days_work = days_work
        
    def __str__(self)->str:
        return f"{super().__str__()},{self.__daily_rate},{self.__days_work},{self.computeSalary()}"
        
    def computeSalary(self)->float:
        return self.__daily_rate * self.__days_work
        
    #setter
    def setDailyRate(self,daily_rate)->None:    self.__daily_rate = daily_rate
    def setDaysWork(self,days_work)->None:      self.__days_work = days_work
    #getter
    def getDailyRate(self)->float:              return self.__daily_rate
    def getDaysWork(self)->float:               return self.__days_work
    
def main()->None:
    d1:Employee = DailyEmployee('1000','durano','dennis','teacher1',800.00,10.0)
    print(d1)
    
if __name__=="__main__":
    main()