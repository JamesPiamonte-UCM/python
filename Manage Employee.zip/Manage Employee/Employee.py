'''
	Employee Class
'''
from Person import Person
from abc import ABC,abstractmethod #abc - abstract base class
class Employee(Person,ABC):
    def __init__(self,idno:str,lastname:str,firstname:str,position:str)->None:
        #instantiate the parent class first
        super().__init__(lastname,firstname)
        self.__idno = idno
        self.__position = position
        
    def __str__(self)->str:#it overrides the parent __str__
        return f"{self.__idno},{super().__str__()},{self.__position}"
        
    def __eq__(self,other:object)->bool:
        if isinstance(other,Employee):
            return self.__idno == other.__idno
    #setters
    def setIdno(self,idno:str)->None:               self.__idno = idno
    def setPosition(self,position:str)->None:       self.__position = position
    #getters
    def getIdno(self)->str:                         return self.__idno
    def getPosition(self)->str:                     return self.__position
    
            
    @abstractmethod
    def computeSalary(self)->float:
        raise NotImplementedError

def main()->None:
    e:Employee = Employee('1000','alpha','delta','teacher1')
    print(e)
    
if __name__=="__main__":
    main()